<?php

include 'include/dbcon.php';
// $con = mysqli_connect("sql200.epizy.com","epiz_23454155","16sw0101","epiz_23454155_pharmacy");

session_start();
error_reporting(0);
$user="null";
if (isset($_SESSION['username'])){


	$user=$_SESSION['username'];

	


}
if(isset($_POST['pid'])!=null){

 	$pid=$_POST['pid'];



$sql = "INSERT INTO addtocart (productid, userid)
VALUES ('$pid', '$userId')";
    
    
if(!mysqli_query($con,$sql)){

    echo 'Not Inserted';
}
}



if(isset($_POST['prodtId'])){
	$prodtId=$_POST['prodtId'];
$con = mysqli_connect("localhost","root","","pharmacy");



 $query= mysqli_query($con,"SELECT * FROM `product` WHERE id=".$prodtId);
 
while ($res=mysqli_fetch_assoc($query)) {
 $proname= $res['proname'];
        $price=$res['price'];
        $descp= $res['descp'];
        $dose=$res['dose'];
          $url= $res['url'];
        $off=$res['off'];
        $type= $res['type'];
        $pid=$res['id'];

}



	
}


   if (isset($_SESSION['name'])){


	$na=$_SESSION['name'];
}
  if (isset($_SESSION['textarea'])){


	$te=$_SESSION['textarea'];
}
if (isset($_SESSION['rate'])){


	$ra=$_SESSION['rate'];
}
  if (isset($_SESSION['date'])){


	$da=$_SESSION['date'];
}


$con = mysqli_connect("localhost","root","","pharmacy");



   

 if (isset($_POST['btn'])){

    $names = $_POST['name'];
    $dates= $_POST['date'];
     $rates= $_POST['rate'];
     $textareas= $_POST['textarea'];



 $query= mysqli_query($con,"select * from ta");
 
while ($res=mysqli_fetch_assoc($query)) {
  $name = $res['names'];
        $date=$res['dates'];
        $textarea= $res['textareas'];
        $rate=$res['rates'];

}





$sql = "INSERT INTO ta(name, `date`,  textarea, rate) VALUES ('$names', '$dates',  '$textareas', '$rates')";
    


if(!mysqli_query($con,$sql)){

    echo "<script>alert('Not inserted')</script>";}
else{
  echo "<script>alert('Inserted')</script>";
  
}

  

   

}

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 

		<title>Online Medical Store</title>

 		<!-- Google font -->
 		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

 		<!-- Bootstrap -->
 		<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css"/>

 		<!-- Slick -->
 		<link type="text/css" rel="stylesheet" href="css/slick.css"/>
 		<link type="text/css" rel="stylesheet" href="css/slick-theme.css"/>

 		<!-- nouislider -->
 		<link type="text/css" rel="stylesheet" href="css/nouislider.min.css"/>

 		<!-- Font Awesome Icon -->
 		<link rel="stylesheet" href="css/font-awesome.min.css">

 		<!-- Custom stlylesheet -->
 		<link type="text/css" rel="stylesheet" href="css/style.css"/>

<script >
	  function add() {
  if (typeof(Storage) !== "undefined") {
    if (localStorage.clickcount) {
      localStorage.clickcount = Number(localStorage.clickcount)+1;
    } else {
      localStorage.clickcount = 1
    }
 var foo=   document.getElementById("wh").innerHTML =  localStorage.clickcount + " ";
 document.getElementById("wh").getValue();
 
  } 
}

</script>
	

    </head>
	<body>
		<!-- HEADER -->
		<header>
			<!-- TOP HEADER -->
			<div id="top-header">
				<div class="container">
					<ul class="header-links pull-left">
						<li><a href="#"><i class="fa fa-phone"></i> +033-95-51-84-45</a></li>
						<li><a href="https://mail.google.com/mail/u/0/#inbox"><i class="fa fa-envelope-o"></i> onlinemedicalstore@gmail.com</a></li>
						<li><a href="#"><i class="fa fa-map-marker"></i> Latifabad unit5 Gorifood Road</a></li>
					</ul>
					<ul class="header-links pull-right">
					
						<li><a href="#"><i class="fa fa-user-o"></i><?php echo$user;?></a></li>
						<a id="b" class="primary-btn cta-btn" href="logout.php" onclick="session_destroy()">Logout</a>
					</ul>
				</div>
			</div>
			<!-- /TOP HEADER -->

			<!-- MAIN HEADER -->
			<div id="header">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<!-- LOGO -->
						<div class="col-md-3">
							<div class="header-logo">
								<a href="#" class="logo" >
								<img src="img/logg.png" alt=""  align="middle" >
								</a>
							</div>
						</div>
						<!-- /LOGO -->

						<!-- SEARCH BAR -->
					<!-- 	<div class="col-md-6">
							<div class="header-search">
								<form>
									<select class="input-select">
										<option value="0">All Categories</option>
										
									</select>
									<input class="input" placeholder="Search here">
									<button class="search-btn">Search</button>
								</form>
							</div>
						</div> -->
						<!-- /SEARCH BAR -->

						<!-- ACCOUNT -->
						<div class="col-md-3 clearfix">
							<div class="header-ctn">
								<!-- Wishlist -->
								<!-- <div>
									<a href="#">
										<i class="fa fa-heart-o"></i>
										<span>Your Wishlist</span>
										<div id="wh" class="qty"></div>
									</a>
								</div> -->
								<!-- /Wishlist -->

								<!-- Cart -->
									
								<!-- Cart -->
								<div class="dropdown">
								<!-- 	<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
										<i class="fa fa-shopping-cart"></i>
										<span>Your Cart</span>
 -->
										<!-- <?php 
                                          

// $co=mysql_connect("localhost","root","");
// $dbb=mysql_select_db("pharmacy",$co);


//  $query= mysql_query("SELECT c.*,p.price,p.proname,p.url FROM `addtocart` c inner join product p on c.productid=p.id where c.userid=".$userId,$co);

//  $rows=mysql_num_rows($query);

// 										 ?>
										<div class="qty"><?php echo $rows; ?></div>
									</a>

									<div class="cart-dropdown">
										<div class="cart-list">

												
								<!-- /Cart -->

								<!-- Menu Toogle -->
								<div class="menu-toggle">
									<a href="#">
										<i class="fa fa-bars"></i>
										<span>Menu</span>
									</a>
								</div>
								<!-- /Menu Toogle -->
							</div>
						</div>
						<!-- /ACCOUNT -->
					</div>
					<!-- row -->
				</div>
				<!-- container -->
			</div>
			<!-- /MAIN HEADER -->
		</header>
		<!-- /HEADER -->

		<!-- NAVIGATION -->
		<nav id="navigation">
			<!-- container -->
			<div class="container">
				<!-- responsive-nav -->
				<div id="responsive-nav">
					<!-- NAV -->
					<ul class="main-nav nav navbar-nav">
						<li class="active"><a href="page1.php">Home</a></li>
						<li><a href="page1.php">Medicines</a></li>
						<li><a href="page1.php">Homopathics Medicines</a></li>
						<li><a href="page1.php">Medical Equipments</a></li>
				
						
					</ul>
					<!-- /NAV -->
				</div>
				<!-- /responsive-nav -->
			</div>
			<!-- /container -->
		</nav>
		<!-- /NAVIGATION -->

		<!-- BREADCRUMB -->
		<div id="breadcrumb" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<ul class="breadcrumb-tree">
						
							
							
							<li class="active">Product name goes here</li>
						</ul>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /BREADCRUMB -->

		<!-- SECTION -->
		<div class="section"  style="background-color: #FEF0E3  ; height: 500px;">
			<!-- container -->
			<div class="container"  >
				<!-- row -->
				<div class="row">
					<!-- Product main img -->
					<div class="col-md-5 col-md-push-2">
						<div id="product-main-img">
							<div class="product-preview">
								<img src=<?php echo $url; ?> alt="" >
							</div>

						</div>
					</div>
					<!-- /Product main img -->

					<!-- Product thumb imgs -->
					<div class="col-md-2  col-md-pull-5">
						<div id="product-imgs">
							<div class="product-preview">
								<img src=<?php echo $url; ?> alt="">
							</div>


						</div>
					</div>
					<!-- /Product thumb imgs -->

					<!-- Product details -->
					<div class="col-md-5">
						<div class="product-details">
							<h2 class="product-name"><?php echo $proname; ?></h2>
							<div>
								<div class="product-rating">
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star-o"></i>
								</div>
								<a class="review-link" href="#">5 Review(s) | Add your review</a>
							</div>
							<div>
								<h3 class="product-price"><?php echo $price; ?><del class="product-old-price">$690.00</del></h3>
								<span class="product-available">In Stock</span>
							</div>
							<p><?php echo $descp; ?>
   </p>

							<div class="product-options">
								
								<label>
									<h1>DOSAGE</h1> 
									<p><?php echo $dose; ?>  
 </p>
								</label>
							</div>

							<div class="add-to-cart">
								<div class="qty-label">
									<!-- Qty
									<div class="input-number">
										<input type="number">
										<span class="qty-up">+</span>
										<span class="qty-down">-</span>
									</div> -->
								</div>
								<form action="checkout.php" method="get">
								<button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> Buy Now</button>
								<input type="hidden" value=<?php echo $pid; ?> name="prodtId">
							</form>
							</div>

							<ul class="product-btns" onclick="add()">
							<!-- 	<li><a href="#"><i class="fa fa-heart-o" onclick="add()"></i> add to wishlist</a></li> -->
							<!-- 	<li><a href="#"><i class="fa fa-exchange"></i> add to compare</a></li> -->
							</ul>

						

							<ul class="product-links">
								<li>Share:</li>
								<li><a href="https://facebook.com"><i class="fa fa-facebook"></i></a></li>
								<li><a href="http://twitter.com"><i class="fa fa-twitter"></i></a></li>
								
								<li><a href="https://mail.google.com/mail/u/0/#inbox"><i class="fa fa-envelope"></i></a></li>
							</ul>

						</div>
					</div>
					<!-- /Product details -->

					<!-- Product tab -->
					<div class="col-md-12">
						<div id="product-tab">
							<!-- product tab nav -->
							<ul class="tab-nav">
								<!-- 
								<li><a data-toggle="tab" href="#tab3">Reviews </a></li> -->
								
							</ul>
							<!-- /product tab nav -->

							<!-- product tab content -->
							<div class="tab-content">
								<!-- tab1  -->
								<div id="tab1" class="tab-pane fade in active">
									<div class="row">
										<div class="col-md-12">
											
										</div>
									</div>
								</div>
								<!-- /tab1  -->

								<!-- tab2  -->
								<div id="tab2" class="tab-pane fade in">
									<div class="row">
										<div class="col-md-12">
										
										</div>
									</div>
								</div>
								<!-- /tab2  -->

								<!-- tab3  -->
								<div id="tab3" class="tab-pane fade in">
									<div class="row">
										<!-- Rating -->
										<div class="col-md-3">
											<div id="rating">
												<div class="rating-avg">
													<!-- <span>3.0</span>
													<div class="rating-stars">
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star-o"></i>
														<i class="fa fa-star-o"></i> -->
													</div>
												</div>
												<ul class="rating">
													
													
												</ul>
											</div>
										</div>
										<!-- /Rating -->
<!--<script type="text/javascript">
	function getDisplay(){
var name=document.getElementById("name").value;
var email=document.getElementById("email").value;
var textarea=document.getElementById("textarea").value;
document.getElementById("reviews").innerHTML=name;<br>
document.getElementById("reviews").innerHTML=email;<br>
document.getElementById("reviews").innerHTML=textarea;<br>
	}
</script>-->
										<!-- Reviews -->
										<div class="col-md-6" id="reviews">
											<div id="reviews" id="reviews">
												<ul class="reviews">
													<li>
														<div class="review-heading" id="bt">
															<?php 

														?>	
															<h5 class="name"><?php echo$na;?></h5>
															
															<h5 class="name"><?php echo$ra;?></h5>
															<h1 class="date"><?php echo $ra;?></h1>
														
															<div class="review-rating">
															<!--	<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star-o empty"></i>-->
															</div>
														</div>
														<div class="review-body" id="reviews">
															<p><?php echo$textareas;?></p>
																<p class="date"><?php echo $da;?></p>
														</div>
													</li>
													
													
												</ul>
												<ul class="reviews-pagination">
												
												</ul>
											</div>
										</div>
										<!-- /Reviews -->

										<!-- Review Form -->
										<div class="col-md-3" >
											<div id="review-form">
												<form class="review-form" method="post">
													<input style="border: 2px solid ; background-color: #FFDAB9"  class="input" type="text" name="name" id="name" placeholder="Your Name">
													<input style="border: 2px solid ; background-color: #FFDAB9" class="input" type="date" name="date"  id="date" placeholder="Date">
														<input style="border: 2px solid ; background-color: #FFDAB9" class="input" type="text" name="rate"  id="rate" placeholder="Rating in points">
													<textarea style="border: 2px solid ; background-color: #FFDAB9" class="input" id="textarea" name="textarea" placeholder="Your Review"></textarea>
													<div class="input-rating">
													<!-- 	<span>Your Rating: </span>
														<div class="stars">
															<input id="star5" name="rating" value="5" type="radio"><label for="star5"></label>
															<input id="star4" name="rating" value="4" type="radio"><label for="star4"></label>
															<input id="star3" name="rating" value="3" type="radio"><label for="star3"></label>
															<input id="star2" name="rating" value="2" type="radio"><label for="star2"></label>
															<input id="star1" name="rating" value="1" type="radio"><label for="star1"></label> -->
														</div>
													</div>
													<button id="bt" name="btn" onclick="getDisplay()" class="primary-btn">Submit</button>
												</form>
											</div>
										</div>
										<!-- /Review Form -->
									</div>
								</div>
								<!-- /tab3  -->
							</div>
							<!-- /product tab content  -->
						</div>
					</div>
					<!-- /product tab -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- Section -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">

					<!-- section title -->
					<div class="col-md-12">
						<div class="section-title">
							
							
					</div>
					<!-- /section title -->

					<!-- Products tab & slick -->
					<div class="col-md-12">
						<div class="row">
							<div class="products-tabs">
								<!-- tab -->
								<div id="tab2" class="tab-pane fade in active">
									<div class="products-slick" data-nav="#slick-nav-2">
										
										<!-- /product -->

									
									
									</div>
									<div id="slick-nav-2" class="products-slick-nav"></div>
								</div>
								<!-- /tab -->
							</div>
						</div>
					</div>
					<!-- /Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- SECTION -->
<!-- If you need Blood bottle -->
						<div class="shiping-details">
						
</div>
		<!-- NEWSLETTER -->
		<!--<div id="newsletter" class="section">
			<!- container 
			<div class="container">
				 row 
			<div class="row">
					<div class="col-md-12">
						<div class="newsletter">
							<p>Sign Up for the <strong>NEWSLETTER</strong></p>
							<form>
								<input class="input" type="email" placeholder="Enter Your Email">
								<button class="newsletter-btn"><i class="fa fa-envelope"></i> Subscribe</button>
							</form>
							<ul class="newsletter-follow">
									<li>
									<a href="https://facebook.com"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a href="https://twitter.com/"><i class="fa fa-twitter"></i></a>
								</li>
								<li>
									<a href="https://www.instagram.com/accounts/login/"><i class="fa fa-instagram"></i></a>
								</li>
								<li>
									<a href="https://www.pinterest.com"><i class="fa fa-pinterest"></i></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				/row -->
			</div>
			<!-- /container -->
		</div> --> 
		<!-- /NEWSLETTER -->

		<!-- FOOTER -->
		<footer id="footer">
			<!-- top footer -->
			<div class="section">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">About Us</h3>
								<p>Online Medical Store provide you to medicines online in your home.</p>
								<ul class="footer-links">
									<li><a href="#"><i class="fa fa-map-marker"></i>Latifabad unit5 Gorifood Road</a></li>
									<li><a href="#"><i class="fa fa-phone"></i>+033-95-51-84-45</a></li>
									<li><a href="https://mail.google.com/mail/u/0/#inbox"><i class="fa fa-envelope-o"></i>onlinemedicalstore@gmail.com</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Categories</h3>
								<ul class="footer-links">
									<li><a href="#">Medicines</a></li>
									<li><a href="#">Homopathics Medicines</a></li>
									<li><a href="#">Medical Equipments</a></li>
							</ul>
							</div>
						</div>

						<div class="clearfix visible-xs"></div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Information</h3>
								<ul class="footer-links">
									<li><a href="Aboutus.php">About Us</a></li>
									<li><a href="Aboutus.php">Contact Us</a></li>
									<li><a href="Aboutus.php">Privacy Policy</a></li>
									<li><a href="Aboutus.php">Orders and Returns</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Service</h3>
								<ul class="footer-links">
									<li><a href="#"><?php echo$user;?></a></li>
								
								</ul>
							</div>
						</div>
					</div>
					<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /top footer -->

			<!-- bottom footer -->
			<div id="bottom-footer" class="section">
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-12 text-center">
							<!-- <ul class="footer-payments">
								<li><a href="#"><i class="fa fa-cc-visa"></i></a></li>
								<li><a href="#"><i class="fa fa-credit-card"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-paypal"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-mastercard"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-discover"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-amex"></i></a></li>
							</ul>
							<span class="copyright">
								
								Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved 
							
							</span> -->
						</div>
					</div>
						<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /bottom footer -->
		</footer>
		<!-- /FOOTER -->

		<!-- jQuery Plugins -->
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/slick.min.js"></script>
		<script src="js/nouislider.min.js"></script>
		<script src="js/jquery.zoom.min.js"></script>
		<script src="js/main.js"></script>

	</body>
</html>
