<?php

include 'include/dbcon.php';
$con = mysqli_connect("localhost","root","","pharmacy");
session_start();
error_reporting(0); 


$user="null";
if (isset($_SESSION['username'])){

 $userId= $_SESSION['userid'];
	$user=$_SESSION['username'];
	 $price= $_SESSION['price'];
	$proname=$_SESSION['proname'];

}

// jh
// if(isset($_POST['pi'])!=null){

//  	$pi=$_POST['pi'];



// $sql = "INSERT INTO addtowish (productid, userid)
// VALUES ('$pi', '$userId')";
    
    
// if(!mysqli_query($con,$sql)){

//     echo 'Not Inserted';
// }
// }
//



if(isset($_POST['pid'])!=null){

 	$pid=$_POST['pid'];



$sql = "INSERT INTO addtocart (productid, userid)
VALUES ('$pid', '$userId')";
    
    
if(!mysqli_query($con,$sql)){

    echo 'Not Inserted';
}
}
//   function add() {
// $counter=0;
// $count=$counter++;
// $sql = "INSERT INTO whish (whish)
// VALUES ('$connt')";
    
    
// if(!mysqli_query($con,$sql)){

//     echo 'Not Inserted';
// }
// }
?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	

		<title>Online Medicle store</title>

		<!-- Google font -->
		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

		<!-- Bootstrap -->
		<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css"/>

		<!-- Slick -->
		<link type="text/css" rel="stylesheet" href="css/slick.css"/>
		<link type="text/css" rel="stylesheet" href="css/slick-theme.css"/>

		<!-- nouislider -->
		<link type="text/css" rel="stylesheet" href="css/nouislider.min.css"/>

		<!-- Font Awesome Icon -->
		<link rel="stylesheet" href="css/font-awesome.min.css">

		<!-- Custom stlylesheet -->
		<link type="text/css" rel="stylesheet" href="css/style.css"/>
<script src="jquery-3.3.1.min.js"></script>
	<script type="text/javascript">
	
		$(document).ready(function() {
$("#b").click(function(){
session_destroy();
});
    //DOM manipulation code
 
});
	</script>
<script >
	  // function add() {
  // if (typeof(Storage) !== "undefined") {
//     if (localStorage.clickcount) {
//       localStorage.clickcount = Number(localStorage.clickcount)+1;
//     } else {
//       localStorage.clickcount = 1
//     }
//  var foo=   document.getElementById("wh").innerHTML =  localStorage.clickcount + " ";
//  document.getElementById("wh").getValue();
//   } 
// }

</script>
    </head>
	<body>
		<!-- HEADER -->
		<header>
			<!-- TOP HEADER -->
			<div id="top-header">
				<div class="container">
					<ul class="header-links pull-left">
						<li><a href="#"><i class="fa fa-phone"></i> +033-95-51-84-45</a></li>
						<li><a href="https://mail.google.com/mail/u/0/#inbox"><i class="fa fa-envelope-o"></i> onlinemedicalstore@gmail.com</a></li>
						<li><a href="#"><i class="fa fa-map-marker"></i> Latifabad unit5 Gorifood Road</a></li>
					</ul>
					<ul class="header-links pull-right">
			
						<li><a href="#"><i class="fa fa-user-o"></i><b><?php echo$user;?></b></a></li>
						<a id="b" class="primary-btn cta-btn" href="logout.php" onclick="session_destroy()">Logout</a>
						
					</ul>
				</div>
			</div>
			<!-- /TOP HEADER -->

			<!-- MAIN HEADER -->
			<div id="header">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<!-- LOGO -->
						<div class="col-md-3">
							<div class="header-logo">
								<a href="#" class="logo">
									<img src="img/logg.png" alt="">
								</a>
							</div>
						</div>
						<!-- /LOGO -->

						<!-- SEARCH BAR -->
						<div class="col-md-6">
							<div class="header-search">
								<form action="#med" method="post">
									<select class="input-select">
										<option value="0">All Categories</option>
										
									</select>
									<input name="pd" class="input" placeholder="Search here">
									<button id="btt" name="btt" class="search-btn" onclick="#med">Search</button>
								</form>
							</div>
						</div>
						<!-- /SEARCH BAR -->

						<!-- ACCOUNT -->
						<div class="col-md-3 clearfix">
							<div class="header-ctn">
								<!-- Wishlist -->
								<div>
									<a href="#">
										<!-- <i class="fa fa-heart-o"></i> -->
										<!-- <span>Your  wishlist</span> -->
							
									<!-- 	<div id="wh" class="qty"><?php //echo $rows; ?></div> -->

									</a>
									
								</div>
								
								<!-- /Wishlist -->

								<!-- Cart -->
								<div class="dropdown">
									<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
										<i class="fa fa-shopping-cart"></i>
										<span>Your Cart</span>

										<?php 
                                          
$con = mysqli_connect("localhost","root","","pharmacy");


 $query= mysqli_query($con,"SELECT c.*,p.price,p.proname,p.url FROM `addtocart` c inner join product p on c.productid=p.id where c.userid=".$userId);

 $rows=mysqli_num_rows($query);

										 ?>
										<div class="qty"><?php echo $rows; ?></div>

									</a>

									<div class="cart-dropdown">
										<div class="cart-list">

												<?php 
                                              
                                             
$con = mysqli_connect("sql200.epizy.com","epiz_23454155","16sw0101","epiz_23454155_pharmacy");



 $query= mysqli_query($con,"SELECT c.*,p.price,p.proname,p.url FROM `addtocart` c inner join product p on c.productid=p.id where c.userid=".$userId);
     $counter=0;
     $total=0;
while ($res=mysqli_fetch_assoc($query)) {
  $productid= $res['productid'];
        $proname=$res['proname'];
        $price= $res['price'];
        $dose=$res['dose'];
          $url= $res['url'];
          $counter++;

                                      ?>
											<div class="product-widget">
												<div class="product-img">
													<img src=<?php echo  $url; ?> alt="">
												</div>
												<div class="product-body">
													<h3 class="product-name"><a href="#"><?php echo $proname; ?></a></h3>
													<h4 class="product-price"><span class="qty">1x</span><?php echo $price; ?></h4>
												</div>
												<!-- <button class="delete"><i class="fa fa-close"></i></button> -->
											</div>
                                             <?php } ?>
                                      

										</div>
										<div class="cart-summary">
											<small><?php echo $counter; ?> Item(s) selected</small>
										</div>
										<div class="cart-btns">
											<!-- <a href="#">View Cart</a> -->
											<a href="">Checkout  <i class="fa fa-arrow-circle-right"></i></a>
										</div>
									</div>
								</div>
								<!-- /Cart -->

								<!-- Menu Toogle -->
								<div class="menu-toggle">
									<a href="#">
										<i class="fa fa-bars"></i>
										<span>Menu</span>
									</a>
								</div>
								<!-- /Menu Toogle -->
							</div>
						</div>
						<!-- /ACCOUNT -->
					</div>
					<!-- row -->
				</div>
				<!-- container -->
			</div>
			<!-- /MAIN HEADER -->
		</header>
		<!-- /HEADER -->

		<!-- NAVIGATION -->
		<nav id="navigation">
			<!-- container -->
			<div class="container">
				<!-- responsive-nav -->
				<div id="responsive-nav">
					<!-- NAV -->
					<ul class="main-nav nav navbar-nav">
						<li class="active"><a href="#">Home</a></li>
						<li><a href="#med">Medicines</a></li>
					
						<li><a href="#med">Homopathics Medicines</a></li>
						<li><a href="#me">Medical Equipments</a></li>
						
						
					</ul>
					<!-- /NAV -->
				</div>
				<!-- /responsive-nav -->
			</div>
			<!-- /container -->
		</nav>
		<!-- /NAVIGATION -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<!-- shop -->
					<div class="col-md-4 col-xs-6">
						<div class="shop">
							<div class="shop-img">
								<img src="./img/im.jpg" alt="" >
							</div>
							<div class="shop-body">
								<h3>Medicines</h3>
								<a href="#med" class="cta-btn">Shop now <i class="fa fa-arrow-circle-right"></i></a>
							</div>
						</div>
					</div>
					<!-- /shop -->

					<!-- shop -->
					<div class="col-md-4 col-xs-6">
						<div class="shop">
							<div class="shop-img">
								<img src="./img/im1.jpg" alt="">
							</div>
							<div class="shop-body">
								<h3>Homopathics<br>Medicines</h3>
								<a href="#med" class="cta-btn">Shop now <i class="fa fa-arrow-circle-right"></i></a>
							</div>
						</div>
					</div>
					<!-- /shop -->

					<!-- shop -->
					<div class="col-md-4 col-xs-6">
						<div class="shop">
							<div class="shop-img">
								<img src="./img/dd.jpg" alt="">
							</div>
							<div class="shop-body">
								<h3>Medicial<br>Equipments</h3>
								<a href="#me" class="cta-btn">Shop now <i class="fa fa-arrow-circle-right"></i></a>
							</div>
						</div>
					</div>
					<!-- /shop -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- SECTION -->
		<div class="section" >
			<!-- container -->
			<div class="container" >
				<!-- row -->
				<div class="row">

					<!-- section title -->
					<div class="col-md-12">
						<div class="section-title" id="med">
<h1 id="med">
	<form   >
							<a href="med" name="med" style="
												background-color: transparent;border: none;overflow: hidden;" >Medicines</a></form></h1>
							
						</div>
					</div>
					<!-- /section title -->

					<!-- Products tab & slick -->
					<div class="col-md-12">
						<div class="row">
							<div class="products-tabs">
								<!-- tab -->
								<div id="tab1" class="tab-pane active">
									<div class="products-slick" data-nav="#slick-nav-1">

<!-- Search -->
 <?php
if (isset($_POST['btt'])) {
	$products=$_POST['pd'];
	//echo $prod;
}
$con = mysqli_connect("localhost","root","","pharmacy");



  $q= mysqli_query($con,"SELECT * FROM `product` WHERE proname='$products'");

while ($r=mysqli_fetch_assoc($q)) {
  $proname= $r['proname'];
        $price=$r['price'];
        $descp= $r['descp'];
        $dose=$r['dose'];
          $url= $r['url'];
        $off=$r['off'];
        $type= $r['type'];
        $pid=$r['id'];





                                      ?>

										<div class="product">
											<div class="product-img">
												<img src=<?php echo $url; ?> alt="" >
												<div class="product-label">
													<span class="sale"><?php echo $off; ?></span>
													<span class="new">NEW</span>
												</div>
											</div>
											<div class="product-body">
												<p class="product-category">Category</p>
												<h3 class="product-name">
                                                    <form action="product.php" method="post">
                                                    	<input type="hidden" value=<?php echo $pid; ?> name="prodtId">
                                                    	

													<button style="
												background-color: transparent;border: none;overflow: hidden;" >
												<?php echo $proname; ?></button></form></h3>
												<h4 class="product-price">
													<?php echo $price; ?><del class="product-old-price">$390.00</del></h4>
												<div class="product-rating">
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
												</div>
												<div class="product-btns">
													<!-- <button onclick="add()" class="add-to-wishlist" ><i class="fa fa-heart-o"></i><span class="tooltipp" onclick="add()">add to wishlist</span></button> -->
												<!-- 	<button class="add-to-compare"><i class="fa fa-exchange"></i><span class="tooltipp">add to compare</span></button>
													<button class="quick-view"><i class="fa fa-eye"></i><span class="tooltipp">quick view</span></button> -->
												</div>
											</div>
											<div class="add-to-cart">
                                                <form action="page1.php" method="post">
												<button type="submit" class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to cart</button>

													<input type="hidden" id="pid" value=<?php echo $pid;?> name="pid">
												</form>
											</div>
										</div>

                                     <?php
                                     }


                                     ?>



<!--  -->
										  <!-- search product -->
<?php  
if (isset($_POST['bt'])) {
	$product= $_POST['product'];
$con = mysqli_connect("localhost","root","","pharmacy");

 $query= mysqli_query($con,"SELECT * FROM `product` WHERE proname='Oxygen mask'");

 while ($res=mysqli_fetch_assoc($query)) {
  $proname= $res['proname'];
        $price=$res['price'];
        $descp= $res['descp'];
        $dose=$res['dose'];
          $url= $res['url'];
        $off=$res['off'];
        $type= $res['type'];
        $pid=$res['id'];

 ?>
<div class="product">
											<div class="product-img">
												<img src=<?php echo $url; ?> alt="" >
												<div class="product-label">
													<span class="sale"><?php echo $off; ?></span>
													<span class="new">NEW</span>
												</div>
											</div>
											<div class="product-body">
												<p class="product-category">Category</p>
												<h3 class="product-name">
                                                    <form action="product.php" method="post">
                                                    	<input type="hidden" value=<?php echo $pid; ?> name="prodtId">
                                                    	

													<button style="
												background-color: transparent;border: none;overflow: hidden;" ><?php echo $proname; ?></button></form></h3>
												<h4 class="product-price"><?php echo $price; ?><del class="product-old-price">$390.00</del></h4>
												<div class="product-rating">
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
												</div>

												<div class="product-btns">
													<form accept="page1.php" method="post"><button onclick="add()" class="add-to-wishlist" ><!-- <i class="fa fa-heart-o"></i> --><span class="tooltipp" onclick="add()">add to wishlist</span></button>
													<!--  -->
													</form>
												<!-- 	<button class="add-to-compare"><i class="fa fa-exchange"></i><span class="tooltipp">add to compare</span></button>
													<button class="quick-view"><i class="fa fa-eye"></i><span class="tooltipp">quick view</span></button> -->
												</div>
											</div>
											<div class="add-to-cart">
                                                <form action="page1.php" method="post">
												<button type="submit" class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to cart</button>

													<input type="hidden" id="pid" value=<?php echo $pid;?> name="pid">
												</form>
											</div>
										</div>

                                     <?php
                                     }

}
                                     ?>

										<!--  search product-->
										<!-- product -->
										
                                      <?php

$con = mysqli_connect("localhost","root","","pharmacy");



 $query= mysqli_query($con,"SELECT * FROM `product` WHERE type='MEDICIANS'");
 
while ($res=mysqli_fetch_assoc($query)) {
  $proname= $res['proname'];
        $price=$res['price'];
        $descp= $res['descp'];
        $dose=$res['dose'];
          $url= $res['url'];
        $off=$res['off'];
        $type= $res['type'];
        $pid=$res['id'];





                                      ?>

										<div class="product">
											<div class="product-img">
												<img src=<?php echo $url; ?> alt="" >
												<div class="product-label">
													<span class="sale"><?php echo $off; ?></span>
													<span class="new">NEW</span>
												</div>
											</div>
											<div class="product-body">
												<p class="product-category">Category</p>
												<h3 class="product-name">
                                                    <form action="product.php" method="post">
                                                    	<input type="hidden" value=<?php echo $pid; ?> name="prodtId">
                                                    	

													<button style="
												background-color: transparent;border: none;overflow: hidden;" ><?php echo $proname; ?></button></form></h3>
												<h4 class="product-price"><?php echo $price; ?><del class="product-old-price">$390.00</del></h4>
												<div class="product-rating">
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
												</div>
												<div class="product-btns">
													<!-- <button onclick="add()" class="add-to-wishlist" ><i class="fa fa-heart-o"></i><span class="tooltipp" onclick="add()">add to wishlist</span></button> -->
												<!-- 	<button class="add-to-compare"><i class="fa fa-exchange"></i><span class="tooltipp">add to compare</span></button>
													<button class="quick-view"><i class="fa fa-eye"></i><span class="tooltipp">quick view</span></button> -->
												</div>
											</div>
											<div class="add-to-cart">
                                                <form action="page1.php" method="post">
												<button type="submit" class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to cart</button>

													<input type="hidden" id="pid" value=<?php echo $pid;?> name="pid">
												</form>
											</div>
										</div>

                                     <?php
                                     }


                                     ?>


																		</div>
									<div id="slick-nav-1" class="products-slick-nav"></div>
								</div>
								<!-- /tab -->
							</div>
						</div>
					</div>
					<!-- Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

	
		<div id="hot-deal" class="set">
			
								
			<!-- container -->
			<div class="container">
				<!-- row -->
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="hot-deal">
							<br>
							<ul class="hot-deal-countdown">
								<li>
									<div>
										<h3>01</h3>
										<span>Days</span>
									</div>
								</li>
								<li>
									<div>
										<h3>5</h3>
										<span>Hours</span>
									</div>
								</li>
								<li>
									<div>
										<h3>30</h3>
										<span>Mins</span>
									</div>
								</li>
								<li>
									<div>
										<h3>50</h3>
										<span>Secs</span>
									</div>
								</li>
							</ul>
							<h2 class="text-uppercase"> deal of this week</h2>
							<p>Up to 10% OFF</p>
							<!--<a class="primary-btn cta-btn" href="product.php">Shop now</a>-->
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
	

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">

					<!-- section title -->
					<div class="col-md-12">
						<div class="section-title">
							<h3 id="me" class="title">Medical Equipment</h3>
							
					</div>
					<!-- /section title -->

					<!-- Products tab & slick -->
					<div class="col-md-12">
						<div class="row">
							<div class="products-tabs">
								<!-- tab -->
								<div id="tab2" class="tab-pane fade in active">
									<div class="products-slick" data-nav="#slick-nav-2">
										<!-- product -->
										 <?php

$con = mysqli_connect("localhost","root","","pharmacy");



 $query= mysqli_query($con,"SELECT * FROM `product` WHERE type='Equipment'");
 
while ($res=mysqli_fetch_assoc($query)) {
  $proname= $res['proname'];
        $price=$res['price'];
        $descp= $res['descp'];
        $dose=$res['dose'];
          $url= $res['url'];
        $off=$res['off'];
        $type= $res['type'];
        $pid=$res['id'];





                                      ?>

										<div class="product">
											<div class="product-img">
												<img src=<?php echo $url; ?> alt="" >
												<div class="product-label">
													<span class="sale"><?php echo $off; ?></span>
													<span class="new">NEW</span>
												</div>
											</div>
											<div class="product-body">
												<p class="product-category">Category</p>
												<h3 class="product-name">
                                                    <form action="product.php" method="post">
                                                    	<input type="hidden" value=<?php echo $pid; ?> name="prodtId">
                                                    	

													<button style="
												background-color: transparent;border: none;overflow: hidden;" ><?php echo $proname; ?></button></form></h3>
												<h4 class="product-price"><?php echo $price; ?><del class="product-old-price">$390.00</del></h4>
												<div class="product-rating">
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
												</div>
												<div class="product-btns" >
													 <form action="page1.php" method="post">
												<!-- 	<button onclick="add()" class="add-to-wishlist" style="width: 50px;"><i class="fa fa-heart-o"></i><span class="tooltipp" onclick="add()" >add to wishlist</span></button> -->

													
												</form>
													<!-- <button class="add-to-compare"><i class="fa fa-exchange"></i><span class="tooltipp">add to compare</span></button> -->
											<!-- 		<button class="quick-view"><i class="fa fa-eye"></i><span class="tooltipp">quick view</span></button> -->

												</div>
											</div>
											<div class="add-to-cart">
                                                <form action="page1.php" method="post">
												<button type="submit" class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to cart</button>

													<input type="hidden" id="pid" value=<?php echo $pid;?> name="pid">
												</form>
											</div>
										</div>

                                     <?php
                                     }


                                     ?>


										<!-- /product -->
									</div>
									<div id="slick-nav-2" class="products-slick-nav"></div>
								</div>
								<!-- /tab -->
							</div>
						</div>
					</div>
					<!-- /Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-4 col-xs-6">
						<div class="section-title">
							<h4 class="title">Top selling</h4>
							<div class="section-nav">
								<div id="slick-nav-3" class="products-slick-nav"></div>
							</div>
						</div>

						<div class="products-widget-slick" data-nav="#slick-nav-3">
							<div>
								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/im1.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Dr.Reckewege*R5</a></h3>
										<h4 class="product-price">$550.00 <del class="product-old-price">$690.00</del></h4>
									</div>
								</div>
								<!-- /product widget -->

								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/sy.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="product.php">Benadryl Syrup</a></h3>
										<h4 class="product-price">$280.00 <del class="product-old-price">$390.00</del></h4>
									</div>
								</div>
								<!-- /product widget -->

								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/the.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Thermometer</a></h3>
										<h4 class="product-price">$280.00 <del class="product-old-price">$320.00</del></h4>
									</div>
								</div>
								<!-- product widget -->
							</div>

							<div>
								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/equi.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="product.php">Inheler</a></h3>
										<h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del></h4>
									</div>
								</div>
								<!-- /product widget -->

								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/leg.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Leg Cramps Syrup</a></h3>
										<h4 class="product-price">$350.00 <del class="product-old-price">$400.00</del></h4>
									</div>
								</div>
								<!-- /product widget -->

								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/im.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Methicobol Injection</a></h3>
										<h4 class="product-price">$280.00 <del class="product-old-price">$350.00</del></h4>
									</div>
								</div>
								<!-- product widget -->
							</div>
						</div>
					</div>

					<div class="col-md-4 col-xs-6">
						<div class="section-title">
							<h4 class="title">Top selling</h4>
							<div class="section-nav">
								<div id="slick-nav-4" class="products-slick-nav"></div>
							</div>
						</div>

						<div class="products-widget-slick" data-nav="#slick-nav-4">
							<div>
								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/tax.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Taxim-O</a></h3>
										<h4 class="product-price">$280.00 <del class="product-old-price">$390.00</del></h4>
									</div>
								</div>
								<!-- /product widget -->

								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/im1.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Dr.Reckewege*R5</a></h3>
										<h4 class="product-price">$550.00 <del class="product-old-price">$690.00</del></h4>
									</div>
								</div>
								<!-- /product widget -->

								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/sy.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Benadryl Syrup</a></h3>
										<h4 class="product-price">$280.00 <del class="product-old-price">$390.00</del></h4>
									</div>
								</div>
								<!-- product widget -->
							</div>

							<div>
								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/leg.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Leg Cramps Syrup</a></h3>
										<h4 class="product-price">$350.00 <del class="product-old-price">$400.00</del></h4>
									</div>
								</div>
								<!-- /product widget -->

								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/equi.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Inheler</a></h3>
										<h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del></h4>
									</div>
								</div>
								<!-- /product widget -->

								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/the.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Thermometer</a></h3>
										<h4 class="product-price">$280.00 <del class="product-old-price">$320.00</del></h4>
									</div>
								</div>
								<!-- product widget -->
							</div>
						</div>
					</div>

					<div class="clearfix visible-sm visible-xs"></div>

					<div class="col-md-4 col-xs-6">
						<div class="section-title">
							<h4 class="title">Top selling</h4>
							<div class="section-nav">
								<div id="slick-nav-5" class="products-slick-nav"></div>
							</div>
						</div>

						<div class="products-widget-slick" data-nav="#slick-nav-5">
							<div>
								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/im.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Methicobol Injection</a></h3>
										<h4 class="product-price">$280.00 <del class="product-old-price">$350.00</del></h4>
									</div>
								</div>
								<!-- /product widget -->

								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/dd.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Blood Pressure Checker</a></h3>
										<h4 class="product-price">$1199.00 <del class="product-old-price">$1299.00</del></h4>
									</div>
								</div>
								<!-- /product widget -->

								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/leg.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Leg Cramps Syrup</a></h3>
										<h4 class="product-price">$350.00 <del class="product-old-price">$400.00</del></h4>
									</div>
								</div>
								<!-- product widget -->
							</div>

							<div>
								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/sy.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Benadryl Syrup</a></h3>
										<h4 class="product-price">$280.00 <del class="product-old-price">$390.00</del></h4>
									</div>
								</div>
								<!-- /product widget -->

								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/tax.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Taxim-O</a></h3>
										<h4 class="product-price">$280.00 <del class="product-old-price">$300.00</del></h4>
									</div>
								</div>
								<!-- /product widget -->

								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="./img/im.jpg" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Category</p>
										<h3 class="product-name"><a href="">Methicobol Injection</a></h3>
										<h4 class="product-price">$280.00 <del class="product-old-price">$350.00</del></h4>
									</div>
								</div>
								<!-- product widget -->
							</div>
						</div>
					</div>

				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- NEWSLETTER -->
		<div id="newsletter" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<div class="newsletter">
							<!-- <p>Sign Up for the <strong>NEWSLETTER</strong></p>
							<form>
								<input class="input" type="email" placeholder="Enter Your Email">
								<button class="newsletter-btn"><i class="fa fa-envelope"></i> Subscribe</button>
							</form>
							<ul class="newsletter-follow">
								<li>
									<a href="https://facebook.com"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a href="https://twitter.com/"><i class="fa fa-twitter"></i></a>
								</li>
								<li>
									<a href="https://www.instagram.com/accounts/login/"><i class="fa fa-instagram"></i></a>
								</li>
								<li>
									<a href="https://www.pinterest.com"><i class="fa fa-pinterest"></i></a>
								</li> -->
							</ul>
						</div>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /NEWSLETTER -->

		<!-- FOOTER -->
		<footer id="footer">
			<!-- top footer -->
			<div class="section">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">About Us</h3>
								<p>Online Medical Store provide you to medicines online in your home. </p>
								<ul class="footer-links">
									<li><a href="#"><i class="fa fa-map-marker"></i>Latifabad unit5 Gorifood Road</a></li>
									<li><a href="#"><i class="fa fa-phone"></i>+033-95-51-84-45</a></li>
									<li><a href="https://mail.google.com/mail/u/0/#inbox"><i class="fa fa-envelope-o"></i>onlinemedicalstore@gmail.com</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Categories</h3>
								<ul class="footer-links">
									
									<li><a href="#">Medicines</a></li>
									<li><a href="#">Homopathics Medicines</a></li>
									<li><a href="#">Medical Equipments</a></li>
									
								</ul>
							</div>
						</div>

						<div class="clearfix visible-xs"></div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Information</h3>
								<ul class="footer-links">
									<li><a href="Aboutus.php">About Us</a></li>
									<li><a href="Aboutus.php">Contact Us</a></li>
									<li><a href="Aboutus.php">Privacy Policy</a></li>
									<li><a href="Aboutus.php">Orders and Returns</a></li>
									
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Service</h3>
								<ul class="footer-links">
									<li><a href="#"><?php echo$user;?></a></li>
									
								</ul>
							</div>
						</div>
					</div>
					<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /top footer -->

			<!-- bottom footer -->
			<div id="bottom-footer" class="section">
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-12 text-center">
							<ul class="footer-payments">
								<!-- <li><a href="#"><i class="fa fa-cc-visa"></i></a></li>
								<li><a href="#"><i class="fa fa-credit-card"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-paypal"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-mastercard"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-discover"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-amex"></i></a></li>
							</ul>
							<span class="copyright">
								
								Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved  
							
							</span> -->
						</div>
					</div>
						<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /bottom footer -->
		</footer>
		<!-- /FOOTER -->

		<!-- jQuery Plugins -->
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/slick.min.js"></script>
		<script src="js/nouislider.min.js"></script>
		<script src="js/jquery.zoom.min.js"></script>
		<script src="js/main.js"></script>

	</body>
</html>
