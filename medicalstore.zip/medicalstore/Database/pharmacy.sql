-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 20, 2019 at 04:56 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pharmacy`
--

-- --------------------------------------------------------

--
-- Table structure for table `addres`
--

CREATE TABLE IF NOT EXISTS `addres` (
`id` int(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `phone` int(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addres`
--

INSERT INTO `addres` (`id`, `name`, `email`, `address`, `city`, `phone`) VALUES
(1, 'Fawad Ahmed', 'fawadahmedarain54@gmail.com', 'Muhallaha amirabad kunri pak sindh district umerkot sindh', 'kunri', 2147483647),
(2, 'Jawad Ahmed', 'jawadahmedarain55@gmail.com', 'Muhallaha amirabad kunri pak sindh district umerkot sindh', 'kunri', 2147483647),
(3, 'Ayaz Ahmed', 'ayazahmedarain56@gmail.com', 'Muhallaha amirabad kunri pak sindh district umerkot sindh', 'kunri', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `addtocart`
--

CREATE TABLE IF NOT EXISTS `addtocart` (
`cardid` int(11) NOT NULL,
  `productid` int(11) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addtocart`
--

INSERT INTO `addtocart` (`cardid`, `productid`, `userid`) VALUES
(15, 7, 2),
(16, 8, 2),
(17, 8, 2),
(18, 8, 2),
(19, 8, 2),
(20, 10, 2),
(21, 7, 2),
(22, 7, 2),
(23, 7, 2),
(24, 12, 2),
(25, 15, 2),
(26, 4, 2),
(27, 6, 0),
(28, 7, 2),
(29, 6, 2),
(30, 10, 6),
(31, 11, 1),
(32, 8, 1),
(33, 16, 1),
(34, 11, 1),
(35, 11, 1),
(36, 10, 1),
(37, 12, 1),
(38, 14, 2);

-- --------------------------------------------------------

--
-- Table structure for table `addtowish`
--

CREATE TABLE IF NOT EXISTS `addtowish` (
  `cardid` int(30) DEFAULT NULL,
  `productid` int(30) NOT NULL,
  `userid` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cancelproducts`
--

CREATE TABLE IF NOT EXISTS `cancelproducts` (
`id` int(30) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `productname` varchar(255) NOT NULL,
  `tel` int(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cancelproducts`
--

INSERT INTO `cancelproducts` (`id`, `name`, `email`, `productname`, `tel`) VALUES
(3, 'Fawad Ahmed', 'fawadahmedarain54@gmail.com', 'Panadol Tablet', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `proname` varchar(255) NOT NULL,
  `pid` int(11) NOT NULL,
  `totalprice` decimal(4,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `clientdata`
--

CREATE TABLE IF NOT EXISTS `clientdata` (
`id` int(30) NOT NULL,
  `name` varchar(255) NOT NULL,
  `proname` varchar(255) NOT NULL,
  `pid` int(30) NOT NULL,
  `totalprice` decimal(16,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
`id` int(11) NOT NULL,
  `proname` varchar(255) NOT NULL,
  `price` decimal(16,4) NOT NULL,
  `descp` varchar(500) NOT NULL,
  `dose` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `off` int(11) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `proname`, `price`, `descp`, `dose`, `url`, `off`, `type`) VALUES
(2, 'Oxygen mask', '9980.0000', 'Nasal cannulas and face masks are used to deliver oxygen to people who don''t otherwise get enough of it. ', 'when you need', 'img/equi.jpg', -35, 'Equipment'),
(4, 'Blood Pressure Checker', '199.0000', 'Blood pressure gauge, is a device used to measure blood pressure, composed of an inflatable cuff to collapse and then release the .artery under the cuff in a controlled manner', 'when to use', 'img/dd.jpg', -30, 'Equipment'),
(5, 'Medical Golves', '120.0000', 'Medical gloves are disposable gloves used during medical examinations and procedures to help prevent cross-contamination between caregivers and patients.', 'when to use', 'img/go.jpg', -30, 'Equipment'),
(6, 'Methicobal Injection', '280.0000', 'Methycobal 500 MCG Injection is a naturally occurring and pure form of Vitamin B12. It is taken to regulate certain vital bodily functions like cell multiplication, blood formation, and protein synthesis. It is used to treat Vitamin B12 deficiency in people with Pernicious Anemia', 'for one week.', 'img/im.jpg', -20, 'MEDICIANS'),
(7, 'DR.Reckewege*R5', '550.0000', 'This is homopathics medicine.Acute and chronic gastritis, dyspepsia, chronic relapsing gastritis with or without ulceration. Especially ulcus parapyloricum. Heartburn, bad taste in mouth, frequent belching, flatulence, meteorism. Acts on the inflamed mucosa of stomach, on the physiology of stomach.', 'GENERALLY 3 TIMES A DAY 10-15 DROPS IN SOME WATER BEFORE MEALS.', 'img/im1.jpg', -30, 'MEDICIANS'),
(8, 'LegCramps Syrup', '350.0000', 'Taking a warm bath or directing the stream of a hot shower onto the cramped muscle also can help. Alternatively, massaging the cramped muscle with ice may relieve pain.', '2 spoon in two times a day', 'img/leg.jpg', -20, 'MEDICIANS'),
(9, 'Sugar Checker', '1200.0000', 'Blood sugar testing requires the use of a small electronic device called a glucometer. The meter reads the amount of sugar in a small sample of blood, usually from your fingertip, that you place on a disposable test strip. ', 'When to use', 'img/sugar.jpg', -30, 'Equipment'),
(10, 'Taxim-O', '280.0000', 'Taxim-O CV 200 Tablet is a combination medicine used to treat a variety of conditions such as urinary tract infections, ear infections, and lung infections caused by bacteria. This medicine is not recommended for use in children less than 10 years of age.', 'two times a day', 'img/tax.jpg', -20, 'MEDICIANS'),
(11, 'Benydral Syrup', '280.0000', 'Diphenhydramine is an antihistamine used to relieve symptoms of allergy, hay fever, and the common cold. These symptoms include rash, itching, watery eyes, itchy eyes/nose/throat, cough, runny nose, and sneezing. It is also used to prevent and treat nausea, vomiting and dizziness caused by motion sickness.', '2 spoon in day', 'img/sy.jpg', -30, 'MEDICIANS'),
(12, 'Syring', '15.0000', 'Use for medical purpose', 'when to use', 'img/syn.jpg', -30, 'Equipment'),
(13, 'Thermometer ', '280.0000', 'Use for Check the fever.', 'When to use', 'img/the.jpg', -20, 'Equipment'),
(14, 'Throat Syrup', '200.0000', 'Boericke & Tafel Cough and Bronchial Syrup Nighttime Description. May temporarily relieve cough due to minor throat and bronchial irritation as may occur with a cold. Helps loosen phlegm (mucus) and thin bronchial secretions to drain bronchial tubes. Soothes the throat.', '2 spoon in a day', 'img/sw.jpg', -20, 'MEDICIANS'),
(15, 'Panadol Syrup', '100.0000', 'This syrup is used to treat mild to moderate pain (from headaches, menstrual periods, toothaches, backaches, osteoarthritis, or cold/flu aches and pains) and to reduce fever.', 'This syrup is use only for 1 year to 12 year child.1 to 6 year 1 table spoon.7 to 12 year 2 table spoon.', 'img/panadol.jpg', -20, 'MEDICIANS'),
(16, 'Panadol Tablet', '80.0000', 'This tablet is used to treat mild to moderate pain (from headaches, menstrual periods, toothaches, backaches, osteoarthritis, or cold/flu aches and pains) and to reduce fever.', 'This tablet is use for above 15 year.\r\n1 to 2 tablet according to the doctor description.', 'img/panadoltablet.jpg', -20, 'MEDICIANS'),
(17, 'Risek Tablet', '120.0000', 'Omeprazole oral capsule is used to reduce the amount of acid in your stomach. It''s used to treat gastric or duodenal ulcers, gastroesophageal reflux disease (GERD), erosive esophagitis, and hypersecretory conditions. This drug is also used to treat stomach infections caused by Helicobacter pylori bacteria.', 'One table in a day.', 'img/rizik.jpg', -10, 'MEDICIANS');

-- --------------------------------------------------------

--
-- Table structure for table `ta`
--

CREATE TABLE IF NOT EXISTS `ta` (
`id` int(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `textarea` varchar(100) NOT NULL,
  `rate` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ta`
--

INSERT INTO `ta` (`id`, `name`, `date`, `textarea`, `rate`) VALUES
(1, 'Fawad Ahmed', '2019-06-06', 'uuuuuuuuuuuuuuuuuu', '***'),
(2, '', '0000-00-00', '', ''),
(3, '', '0000-00-00', '', ''),
(4, 'Fawad Ahmed', '0076-07-07', '', ''),
(5, 'Fawad Ahmed', '0005-06-06', 'jjhhuhu', '****'),
(6, '', '0000-00-00', '', ''),
(7, '', '0000-00-00', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'fawad', 'fawad'),
(2, 'Fawad Ahmed', '16sw01'),
(6, 'admin', 'admin'),
(7, 'Fawad Ahmed', '16sw01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addres`
--
ALTER TABLE `addres`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addtocart`
--
ALTER TABLE `addtocart`
 ADD PRIMARY KEY (`cardid`);

--
-- Indexes for table `cancelproducts`
--
ALTER TABLE `cancelproducts`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clientdata`
--
ALTER TABLE `clientdata`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ta`
--
ALTER TABLE `ta`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addres`
--
ALTER TABLE `addres`
MODIFY `id` int(50) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `addtocart`
--
ALTER TABLE `addtocart`
MODIFY `cardid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `cancelproducts`
--
ALTER TABLE `cancelproducts`
MODIFY `id` int(30) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `clientdata`
--
ALTER TABLE `clientdata`
MODIFY `id` int(30) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `ta`
--
ALTER TABLE `ta`
MODIFY `id` int(30) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
