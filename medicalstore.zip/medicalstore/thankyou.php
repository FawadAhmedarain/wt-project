
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	

		<title>Online Medicle store</title>

		<!-- Google font -->
		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

		<!-- Bootstrap -->
		<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css"/>

		<!-- Slick -->
		<link type="text/css" rel="stylesheet" href="css/slick.css"/>
		<link type="text/css" rel="stylesheet" href="css/slick-theme.css"/>

		<!-- nouislider -->
		<link type="text/css" rel="stylesheet" href="css/nouislider.min.css"/>

		<!-- Font Awesome Icon -->
		<link rel="stylesheet" href="css/font-awesome.min.css">

		<!-- Custom stlylesheet -->
		<link type="text/css" rel="stylesheet" href="css/style.css"/>

</head>
<body>
	<div class="jumbotron text-xs-center">
  <h1 class="display-3" style="text-align: center;">Thank You!</h1>
  <p class="lead" style="text-align: center; color: #FF8C00 "> For purchasing pur product.</p>
  <p class="lead" style="text-align: center; color: #FF8C00 "> Successfull purchase product.</p>
  <p class="lead" style="text-align: center; color: #FF8C00 "> Your product will deliver your within 1 and half hour..</p>
  <hr>
  <p>
    Having trouble? <a href="Aboutus.php">Contact us</a>
  </p>
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="page1.php" role="button">Continue to homepage</a>
  </p>
</div>
</body>
</html>















