<?php

//include 'include/dbcon.php';
include 'include/dbcon.php';
session_start();
$user="null";
if (isset($_SESSION['username'])){


	$user=$_SESSION['username'];
}
if (isset($_POST['place'])) {
	# code...
}

if(isset($_POST['prodtId'])){
	$prodtId=$_POST['prodtId'];
$con = mysqli_connect("localhost","root","","pharmacy");




 $query= mysqli_query($con,"SELECT * FROM `product` WHERE id=".$prodtId);
 
while ($res=mysqli_fetch_assoc($query)) {
 $proname= $res['proname'];
        $price=$res['price'];
        $descp= $res['descp'];
        $dose=$res['dose'];
          $url= $res['url'];
        $off=$res['off'];
        $type= $res['type'];
        $pid=$res['id'];

}



	
}

if (isset($_POST['btn'])){

    $name = $_POST['name'];
    $email= $_POST['email'];

    $address = $_POST['address'];
    $city= $_POST['city'];
    $phone= $_POST['phone'];
        
      

$sql = "INSERT INTO addres (name, email, address, city, phone)
VALUES ('$name', '$email', '$address', '$city', '$phone')";
    
//   $query= "INSERT INTO clientdata (name, proname, pid, totalprice)
// VALUES ('$name', '$email', '$address', '$city', '$phone')"
if(!mysqli_query($con,$sql)){

    echo 'Not Inserted';
}
else{
  echo "<script>alert('Submit Successfully')</script>";
  
}

    $name="";
    $email="";
    $address="";
    $city="";
    $phone="";
    }
    if (isset($_POST['cbt'])){

    $name = $_POST['name'];
    $email= $_POST['email'];


  $productname=$_POST['product'];
    $phone= $_POST['phone'];
        
      

$sql = "INSERT INTO cancelproducts (name, email, productname, tel)
VALUES ('$name', '$email', '$productname', '$phone')";
    
//   $query= "INSERT INTO clientdata (name, proname, pid, totalprice)
// VALUES ('$name', '$email', '$address', '$city', '$phone')"
if(!mysqli_query($con,$sql)){

    echo 'Not Inserted';
}
else{
  echo "<script>alert('Cancel product successfully')</script>";
  
}
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-
		UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<title>Online medical Store</title>

 		<!-- Google font -->
 		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

 		<!-- Bootstrap -->
 		<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css"/>

 		<!-- Slick -->
 		<link type="text/css" rel="stylesheet" href="css/slick.css"/>
 		<link type="text/css" rel="stylesheet" href="css/slick-theme.css"/>

 		<!-- nouislider -->
 		<link type="text/css" rel="stylesheet" href="css/nouislider.min.css"/>

 		<!-- Font Awesome Icon -->
 		<link rel="stylesheet" href="css/font-awesome.min.css">

 		<!-- Custom stlylesheet -->
 		<link type="text/css" rel="stylesheet" href="css/style.css"/>

		<script >
	  function add() {
  if (typeof(Storage) !== "undefined") {
    if (localStorage.clickcount) {
      localStorage.clickcount = Number(localStorage.clickcount)+1;
    } else {
      localStorage.clickcount = 1
    }
 var $foo=   document.getElementById("wh").innerHTML =  localStorage.clickcount  " ";
 print(var);

 document.getElementById("wh").getValue();
  } 
   <?php echo $var ?>
}

</script>

    </head>
	<body>
		<!-- HEADER -->
		<header>
			<!-- TOP HEADER -->
			<div id="top-header">
				<div class="container">
					<ul class="header-links pull-left">
						<li><a href="#"><i class="fa fa-phone"></i> +033-95-51-84-45</a></li>
						<li><a href="https://mail.google.com/mail/u/0/#inbox"><i class="fa fa-envelope-o"></i> onlinemedicalstore@gmail.com</a></li>
						<li><a href="#"><i class="fa fa-map-marker"></i> Latifabad unit5 Gorifood Road</a></li>
					</ul>
					<ul class="header-links pull-right">
					
						<li><a href="#"><i class="fa fa-user-o"></i> <?php echo$user;?></a></li>
						<a id="b" class="primary-btn cta-btn" href="logout.php" onclick="session_destroy()">Logout</a>
					</ul>
				</div>
			</div>
			<!-- /TOP HEADER -->

			<!-- MAIN HEADER -->
			<div id="header">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
					<!-- LOGO -->
						<div class="col-md-3">
							<div class="header-logo">
								<a href="#" class="logo">
									<img src="img/logg.png" alt="" >
								</a>
							</div>
						</div>
						<!-- /LOGO -->

						<!-- SEARCH BAR -->
						<div class="col-md-6">
							<div class="header-search">
								<!-- <form>
									<select class="input-select">
										<option value="0">All Categories</option>
										
									</select>
									<input class="input" placeholder="Search here">
									<button class="search-btn">Search</button>
								</form> -->
							</div>
						</div>
						<!-- /SEARCH BAR -->

						<!-- ACCOUNT -->
						<div class="col-md-3 clearfix">
							<div class="header-ctn">
								<!-- Wishlist -->
								<div>
									<!-- <a href="#">
										<i class="fa fa-heart-o"></i>
										<span onclick="add()">Your Wishlist</span>
										<div  id="wh" class="qty"></div>
									</a>  -->
								</div>
								<!-- /Wishlist -->

								<!-- Cart -->
								<!-- <div class="dropdown">
									<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
										<i class="fa fa-shopping-cart"></i>
										<span>Your Cart</span>
										<div class="qty">6</div>
									</a>
									<div class="cart-dropdown">
										<div class="cart-list">
											<div class="product-widget">
												<div class="product-img">
													<img src="./img/im1.jpg" alt="">
												</div>
												<div class="product-body">
													<h3 class="product-name"><a href="#">product name goes here</a></h3>
													<h4 class="product-price"><span class="qty">1x</span>$550.00</h4>
												</div>
												<button class="delete"><i class="fa fa-close"></i></button>
											</div>

											<div class="product-widget">
												<div class="product-img">
													<img src="./img/product02.png" alt="">
												</div>
												<div class="product-body">
													<h3 class="product-name"><a href="#">product name goes here</a></h3>
													<h4 class="product-price"><span class="qty">3x</span>$280.00</h4>
												</div>
												<button class="delete"><i class="fa fa-close"></i></button>
											</div>
										</div>
										<div class="cart-summary">
											<small>3 Item(s) selected</small>
											<h5>SUBTOTAL: $830.00</h5>
										</div>
										<div class="cart-btns">
											<a href="#">View Cart</a>
											<a href="#">Checkout  <i class="fa fa-arrow-circle-right"></i></a>
										</div>
									</div>
								</div> -->
								<!-- /Cart -->

								<!-- Menu Toogle -->
								<div class="menu-toggle">
									<a href="#">
										<i class="fa fa-bars"></i>
										<span>Menu</span>
									</a>
								</div>
								<!-- /Menu Toogle -->
							</div>
						</div>
						<!-- /ACCOUNT -->
					</div>
					<!-- row -->
				</div>
				<!-- container -->
			</div>
			<!-- /MAIN HEADER -->
		</header>
		<!-- /HEADER -->

		<!-- NAVIGATION -->
		<nav id="navigation">
			<!-- container -->
			<div class="container">
				<!-- responsive-nav -->
				<div id="responsive-nav">
					<!-- NAV -->
					<ul class="main-nav nav navbar-nav">
						<li class="active"><a href="page1.php">Home</a></li>
					
					</ul>
					<!-- /NAV -->
				</div>
				<!-- /responsive-nav -->
			</div>
			<!-- /container -->
		</nav>
		<!-- /NAVIGATION -->

		<!-- BREADCRUMB -->
		<div id="breadcrumb" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<h3 class="breadcrumb-header">Checkout</h3>
						<ul class="breadcrumb-tree">
							
						</ul>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /BREADCRUMB -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">

					<div class="col-md-7">
						<!-- Billing Details -->
						<div class="billing-details">
							<div class="section-title">
								<h3 class="title">Billing address</h3>
							</div>
							<div class="form-group" >
								<form  method="post">
								<input class="input" type="text" name="name" placeholder="Name">
							</div>
							<div class="form-group">
								
							</div>
							<div class="form-group">
								<input class="input" type="email" name="email" placeholder="Email">
							</div>
							<div class="form-group">
								<input class="input" type="text" name="address" placeholder="Address">
							</div>
							<div class="form-group">
								<input class="input" type="text" name="city" placeholder="City">
							</div>
							
							
							<div class="form-group">
								<input class="input" type="tel" name="phone" placeholder="Telephone">
							</div>
						 <div class="form-group">
                    <input id="submit" type="submit" name="btn" value="Submit" class="btn btn-outline-danger float-right login_btn" style="width: 300px; height: 50px; border: 2px solid #B22222; color: white;
                    background-color: #B22222; font-style: bold;font-size:18px;  ">
                </div>
							<div class="form-group">
								<div class="input-checkbox">
									
									<label for="create-account">
										<span></span>
										
									</label>
									</form>
								</div>
							</div>
						</div>
						<!-- /Billing Details -->

						<!-- Shiping Details -->
						<div class="shiping-details">
							<div class="section-title">
								
							</div>
							<div class="input-checkbox">
							<!-- <input type="checkbox" id="shiping-address"> -->
								<label for="shiping-address">
									<span></span>
									
								</label>
								<div class="caption">
									<div class="form-group">
										
									</div>
									<div class="form-group">
									
									</div>
									<div class="form-group">
									
									</div>
									<div class="form-group">
										
									</div>
									<div class="form-group">
										
									</div>
									<div class="form-group">
										
									</div>
									
									<div class="form-group">
										
									</div>
								</div>
							</div>
						</div>
						<!-- /Shiping Details -->

<!-- cancel product -->
						<div class="shiping-details">
							<div class="section-title">
								<h3 class="title">Cancel Product</h3>
							</div>
							<div class="input-checkbox">
								<input type="checkbox" id="shiping-address" style="width: 50px; background-color: black">
								<label for="shiping-address">
									<span></span>
									Cancel product here
								</label>
								<div class="caption">
									<div class="form-group">
										<form method="post">
										<input class="input" type="text" name="name" placeholder=" Name">
									</div>
								
									<div class="form-group">
										<input class="input" type="email" name="email" placeholder="Email">
									</div>
									<div class="form-group">
										<input class="input" type="text" name="product" placeholder="Product name">
									</div>
									
									
									
									<div class="form-group">
										<input class="input" type="tel" name="phone" placeholder="Telephone">

									</div>
									<div class="form-group">
									 <input id="submit" type="submit" name="cbt" value="Cancel Product" class="btn btn-outline-danger float-right login_btn" style="width: 300px; height: 50px; border: 2px solid #B22222; color: white;
                    background-color: #B22222; font-style: bold;font-size:18px;  ">
                    </form>
                </div>
								</div>
							</div>
						</div>

						<!-- Cancel Product -->
						<div class="order-notes">
							
						</div>
						<!-- /Order notes -->
					</div>

					<!-- Order Details -->
					<div class="col-md-5 order-details">
						<div class="section-title text-center">
							<h3 class="title">Your Order</h3>
						</div>
						<div class="order-summary">
							<div class="order-col">
								<?php

	$con = mysqli_connect("localhost","root","","pharmacy");




 $query= mysqli_query($con,"SELECT * FROM `product` WHERE id=".$_GET['prodtId']);
 
while ($res=mysqli_fetch_assoc($query)) {
 $proname= $res['proname'];
        $price=$res['price'];
        $descp= $res['descp'];
        $dose=$res['dose'];
          $url= $res['url'];
        $off=$res['off'];
        $type= $res['type'];
        $pid=$res['id'];

}

?>

							</div>
							<div class="order-products">
                                    <div class="order-col">
                                    				<?php 
						if (isset($_POST['pl'])){
$con = mysqli_connect("localhost","root","","pharmacy");

 $username = $_POST['username'];
    $password= $_POST['password'];
$user; $proname; $pid; $price; 
$sq= "INSERT INTO client (name, proname, pid,totalprice)
VALUES ('$user', '$proname', ' $pid', ' $price' )";
    
    
if(!mysqli_query($con,$sq)){

   echo "<script>alert('not insert')</script>";
}
else{
  echo "<script>alert('Create account successfully')</script>";
  
}			
						}
?>
	
                                <div><strong>Name</strong></div>
                                <div><strong><?php echo$user;?></strong></div>
									<!-- <div><?php //echo $proname; ?></div>
									<div><?php //echo $proname; ?></div> -->
								</div>
								
								
									<div class="order-col">
                                <div><strong>PRODUCT</strong></div>
								<div><strong>TOTAL</strong></div>
								
								</div>
								<div class="order-col">
								
                                <div>ProductId</div>
								<div><?php echo$pid;?></div>
								
								
								</div>

								<div class="order-col">

									<div><?php echo $proname; ?></div>
									<div><?php echo $price; ?></div>
								</div>
								<div class="order-col">
									<!-- <div><?php //echo $proname; ?></div>
									<div><?php //echo $proname; ?></div> -->
								</div>
							</div>
							<div class="order-col">
								<div>Shiping</div>
								<div><strong>FREE</strong></div>
							</div>
							<div class="order-col">
								<div><strong>TOTAL</strong></div>
								<div><strong class="order-total"><?php echo $price; ?></strong></div>
							</div>
						</div>
						<div class="payment-method">
							<div class="input-radio">
								<h3>Cash on delivery..</h3>
								<!-- <input type="radio" name="payment" id="payment-1"> -->
								<label for="payment-1">
									<span></span>
									<!--Direct Bank Transfer -->
									
								</label>
								<div class="caption">
									<!--<p>Enter bank code and Bank Chalan number</p> -->
									<div class="form-group">
								<!--	<input class="input" type="text" name="Bank-code" placeholder="Enter Bank code"> -->
									</div>
									<div class="form-group">
									<!--	<input class="input" type="number" name="Chalan-number" placeholder="Enter Bank Chalan number"> -->
									</div>
								</div>
								
							</div>
							<!-- Cancel Prtoduct -->

							<!-- Cancel Product -->
							<div class="input-radio">
							<!--	<input type="radio" name="payment" id="payment-2"> -->
								<label for="payment-2">
									<span></span>
									<!-- Easy Passa
								</label>
								<div class="caption">
									<p>Enter eassy passa code and cnic number </p>
									<div class="form-group">
										<input class="input" type="text" name="Code" placeholder="Enter Code">
									</div>
									<div class="form-group">
										<input class="input" type="text" name="cnic" placeholder="Enter CNIC number">
									</div>
								</div>
							</div>
							
						</div>
						<div class="input-checkbox">
							<input type="checkbox" id="terms">
							<label for="terms">
								<span></span>
								I've read and accept the <a href="#">terms & conditions</a>
							</label> -->
						</div>
								<form action="thankyou.php" method="post" name="pl">
						<button id="pl"  href="thankyou.php" name="pl" class="primary-btn order-submit">Place order</button>
						</form>
					</div>
					<!-- /Order Details -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- NEWSLETTER -->
		<div id="newsletter" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<div class="newsletter">
							<!-- <p>Sign Up for the <strong>NEWSLETTER</strong></p>
							<form>
								<input class="input" type="email" placeholder="Enter Your Email">
								<button class="newsletter-btn"><i class="fa fa-envelope"></i> Subscribe</button>
							</form>
							<ul class="newsletter-follow">
							<li>
									<a href="https://facebook.com"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a href="https://twitter.com/"><i class="fa fa-twitter"></i></a>
								</li>
								<li>
									<a href="https://www.instagram.com/accounts/login/"><i class="fa fa-instagram"></i></a>
								</li>
								<li>
									<a href="https://www.pinterest.com"><i class="fa fa-pinterest"></i></a> -->
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /NEWSLETTER -->

		<!-- FOOTER -->
		<footer id="footer">
			<!-- top footer -->
			<div class="section">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">About Us</h3>
								<p>Online Medical Store provide you to medicines online in your home. </p>
								<ul class="footer-links">
									<li><a href="#"><i class="fa fa-map-marker"></i>Latifabad unit5 Gorifood Road</a></li>
									<li><a href="#"><i class="fa fa-phone"></i>+033-95-51-84-45</a></li>
									<li><a href="https://mail.google.com/mail/u/0/#inbox"><i class="fa fa-envelope-o"></i>onlinemedicalstore@gmail.com</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Categories</h3>
								<ul class="footer-links">
							
									<li><a href="#">Medicines</a></li>
									<li><a href="#">Homopathics Medicines</a></li>
									<li><a href="#">Medical Equipments</a></li>
								
								</ul>
							</div>
						</div>

						<div class="clearfix visible-xs"></div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Information</h3>
								<ul class="footer-links">
									<li><a href="Aboutus.php">About Us</a></li>
									<li><a href="Aboutus.php">Contact Us</a></li>
									<li><a href="Aboutus.php">Privacy Policy</a></li>
									<li><a href="Aboutus.php">Orders and Returns</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Service</h3>
								<ul class="footer-links">
									<li><a href="#"><?php echo$user;?></a></li>
								
								</ul>
							</div>
						</div>
					</div>
					<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /top footer -->

			<!-- bottom footer -->
			<div id="bottom-footer" class="section">
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-12 text-center">
							<ul class="footer-payments">
								<!-- <li><a href="#"><i class="fa fa-cc-visa"></i></a></li>
								<li><a href="#"><i class="fa fa-credit-card"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-paypal"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-mastercard"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-discover"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-amex"></i></a></li>
							</ul>
							<span class="copyright">
								
								Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved  
							
							</span> -->
						</div>
					</div>
						<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /bottom footer -->
		</footer>
		<!-- /FOOTER -->

		<!-- jQuery Plugins -->
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/slick.min.js"></script>
		<script src="js/nouislider.min.js"></script>
		<script src="js/jquery.zoom.min.js"></script>
		<script src="js/main.js"></script>

	</body>
</html>
